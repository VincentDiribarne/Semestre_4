#include <iostream>

class Matrice {
public:
	//Exo 1
	Matrice();
	Matrice(int nb1, int nb2);
	Matrice(int nb1, int nb2, int* tab);
	Matrice(const Matrice& matrice);
	void affiche();

	//Exo 2
	int getValue(int nb1, int nb2);
	void setValue(int nb1, int nb2, int nb3);
	int getNbColonne();
	int getNbLigne();

	//Exo 3
	bool egal(Matrice m);
	bool different(Matrice m);
	void affectation(Matrice& m);
	int& value(int nb1, int nb2);

	//Exo 4
	void multiplication(int nb);
	void multiplication(Matrice m, Matrice m2);
	void soustraction(Matrice m, Matrice m2);
	void addition(Matrice m, Matrice m2);

	~Matrice();

private:
	int nbLigne = 0;
	int nbColonne = 0;
	int** tab;

};