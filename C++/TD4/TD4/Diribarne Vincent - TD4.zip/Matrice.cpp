#include "Matrice.h"
using namespace std;

Matrice::Matrice() {
	this->nbLigne = 1;
	this->nbColonne = 1;
	this->tab = new int* [1];
	this->tab[0] = new int[1];
	this->tab[0][0] = 0;
}

Matrice::Matrice(int nb1, int nb2) {
	if (nb1 <= 0) {
		this->nbLigne = 1;
	}
	else {
		this->nbLigne = nb1;
	}

	if (nb2 <= 0) {
		this->nbColonne = 1;
	}
	else {
		this->nbColonne = nb2;
	}

	this->tab = new int* [this->nbLigne];
	for (int i = 0; i < this->nbLigne; ++i) { this->tab[i] = new int[this->nbColonne]; }

	for (int i = 0; i < nbLigne; i++) {
		for (int j = 0; j < nbColonne; j++) {
			this->tab[i][j] = 0;
		}
	}
}

Matrice::Matrice(int nb1, int nb2, int* tab) {
	if (nb1 <= 0) {
		this->nbLigne = 1;
	}
	else {
		this->nbLigne = nb1;
	}

	if (nb2 <= 0) {
		this->nbColonne = 1;
	}
	else {
		this->nbColonne = nb2;
	}

	this->tab = new int* [nbLigne];
	for (int i = 0; i < this->nbLigne; ++i) { this->tab[i] = new int[this->nbColonne]; }

	int interateur = 0;
	for (int i = 0; i < nbLigne; i++) {
		for (int j = 0; j < nbColonne; j++) {
			this->tab[i][j] = tab[interateur++];
		}
	}
}

Matrice::Matrice(const Matrice& matrice) : nbLigne(matrice.nbLigne), nbColonne(matrice.nbColonne) {
	this->tab = new int* [this->nbLigne];
	for (int i = 0; i < this->nbLigne; ++i) { this->tab[i] = new int[this->nbColonne]; }
	for (int i = 0; i < this->nbLigne; ++i) {
		for (int j = 0; j < this->nbColonne; ++j) {
			this->tab[i][j] = matrice.tab[i][j];
		}
	}
}

void Matrice::affiche() {
	cout << "Matrice : " << endl;
	for (int i = 0; i < this->nbLigne; i++) {
		for (int j = 0; j < this->nbColonne; j++) {
			cout << this->tab[i][j] << " ";
		}
		cout << endl;
	}
	cout << endl;

}

int Matrice::getValue(int nbLigne, int nbColonne) {
	if (nbLigne > getNbLigne()) {
		cout << "Le nombre de ligne fourni '" << nbLigne << "' ne peut pas superieur a " << getNbLigne() << endl;
		exit(-1);
	}

	if (nbColonne > getNbColonne()) {
		cout << "Le nombre de colonne fourni '" << nbColonne << "' ne peut pas superieur a " << getNbColonne() << endl;
		exit(-1);
	}

	return this->tab[nbLigne][nbColonne];
}

void Matrice::setValue(int nbLigne, int nbColonne, int nombreModif) {
	if (nbLigne > getNbLigne()) {
		cout << "Le nombre de ligne fourni '" << nbLigne << "' ne peut pas superieur a " << getNbLigne() << endl;
		exit(-1);
	}

	if (nbColonne > getNbColonne()) {
		cout << "Le nombre de colonne fourni '" << nbColonne << "' ne peut pas superieur a " << getNbColonne() << endl;
		exit(-1);
	}

	this->tab[nbLigne][nbColonne] = nombreModif;
}

int Matrice::getNbColonne() {
	return this->nbColonne;
}

int Matrice::getNbLigne() {
	return this->nbLigne;
}

bool Matrice::egal(Matrice m) {
	if (this->getNbLigne() != m.getNbLigne()) {
		return false;
	}

	if (this->getNbColonne() != m.getNbColonne()) {
		return false;
	}

	for (int i = 0; i < m.getNbColonne(); i++) {
		for (int j = 0; i < m.getNbLigne(); i++) {
			if (this->tab[i][j] == m.tab[i][j]) {
				return true;
			}
		}
	}

	return false;
}

bool Matrice::different(Matrice m) {
	return !egal(m);
}

void Matrice::affectation(Matrice& m) {
	this->nbLigne = m.nbLigne;
	this->nbColonne = m.nbColonne;
	this->tab = new int* [m.nbLigne];
	for (int i = 0; i < this->nbLigne; ++i) { this->tab[i] = new int[this->nbColonne]; }
	
	for (int i = 0; i < m.nbLigne; i++) {
		for (int j = 0; j < m.nbColonne; j++) {
			this->tab[i][j] = m.tab[i][j];
		}
	}
}

int& Matrice::value(int nb1, int nb2) {
	return this->tab[nb1][nb2];
}

void Matrice::multiplication(int nb) {
	for (int i = 0; i < this->nbLigne; i++) {
		for (int j = 0; j < this->nbColonne; j++) {
			this->tab[i][j] *= nb;
		}
	}
}

void Matrice::multiplication(Matrice m, Matrice m2) {
	Matrice ret = Matrice(m.nbLigne, m2.nbColonne);
	if (m.getNbLigne() != m2.getNbColonne()) {
		cout << "Les deux matrices ne peuvent pas �tre multipli�es (mauvaise dimension)" << endl;
		exit(-1);
	}

	for (int i = 0; i < m.getNbLigne(); ++i) {
		for (int j = 0; j < m2.getNbColonne(); ++j) {
			for (int k = 0; k < m.getNbColonne(); ++k) {
				ret.tab[i][j] += m.tab[i][k] * m2.tab[k][j];
			}
		}
	}

	this->affectation(ret);
}

void Matrice::soustraction(Matrice m, Matrice m2) {
	if (m.getNbLigne() != m2.getNbLigne()) {
		cout << "Les deux matrices ne sont pas de m�me dimension" << endl;
		exit(-1);
	}

	if (m.getNbColonne() != m2.getNbColonne()) {
		cout << "Les deux matrices ne sont pas de m�me dimension" << endl;
		exit(-1);
	}

	for (int i = 0; i < m.nbLigne; i++) {
		for (int j = 0; j < m.nbColonne; j++) {
			this->tab[i][j] = (m.tab[i][j] - m2.tab[i][j]);
		}
	}
}

void Matrice::addition(Matrice m, Matrice m2) {
	if (m.getNbLigne() != m2.getNbLigne()) {
		cout << "Les deux matrices ne sont pas de m�me dimension" << endl;
		exit(-1);
	}

	if (m.getNbColonne() != m2.getNbColonne()) {
		cout << "Les deux matrices ne sont pas de m�me dimension" << endl;
		exit(-1);
	}

	for (int i = 0; i < m.nbLigne; i++) {
		for (int j = 0; j < m.nbColonne; j++) {
			this->tab[i][j] = (m.tab[i][j] + m2.tab[i][j]);
		}
	}
}

Matrice::~Matrice() {
	for (int i = 0; i < this->nbLigne; i++) {
		delete[] this->tab[i];
	}
	delete[] tab;
	this->nbLigne = NULL;
	this->nbColonne = NULL;
}
